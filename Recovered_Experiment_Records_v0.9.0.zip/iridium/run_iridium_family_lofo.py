#!/usr/bin/env python3
"""Run the locked five-fold Iridium-family replication experiment."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

import numpy as np

import experiment
from experiment import (
    FINAL_SEEDS,
    Encoder,
    TrainConfig,
    atomic_json,
    load_flights,
    object_sha256,
    sha256,
    train_one,
)
from run_kinematic_term_ablation import loss_for


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "outputs" / "iridium_family_lofo"
PROTOCOL = ROOT / "IRIDIUM_FAMILY_LOFO_PROTOCOL.md"
MASK = ROOT / "data" / "fractions" / "train_005pct.csv"
KINEMATIC_WEIGHT = 33.6822579609781
IRIDIUM_FLIGHTS = (
    "iridium_next_1",
    "iridium_next_3",
    "iridium_next_4",
    "iridium_next_6",
    "iridium_next_8",
)
VARIANTS = {
    "nn": {"method": "nn", "epochs": 560, "active_terms": []},
    "full_kcnn": {
        "method": "kcnn",
        "epochs": 400,
        "active_terms": [
            "vertical_rate_nonnegative",
            "vertical_rate_le_speed",
            "speed_nonnegative",
        ],
    },
    "upper_bound_only": {
        "method": "kcnn",
        "epochs": 400,
        "active_terms": ["vertical_rate_le_speed"],
    },
}


def aggregate_fold(records, variant):
    selected = [row for row in records if row["variant"] == variant]
    if len(selected) != 5:
        raise RuntimeError((variant, len(selected)))
    keys = ("h_rmse_m", "v_rmse_m_s", "composite")
    return {
        "seed_records": sorted(selected, key=lambda row: row["seed"]),
        "seed_mean": {key: float(np.mean([row[key] for row in selected])) for key in keys},
        "seed_sd_descriptive": {key: float(np.std([row[key] for row in selected], ddof=1)) for key in keys},
    }


def main():
    if not PROTOCOL.is_file() or not MASK.is_file():
        raise FileNotFoundError("Protocol and frozen mask are required")
    train_rows, _, train_sources = load_flights(ROOT / "data" / "flights")
    train_ids = {row["flight_id"] for row in train_rows}
    if not set(IRIDIUM_FLIGHTS).issubset(train_ids):
        raise RuntimeError("Iridium fold flights are not all in the training partition")
    calibration = json.loads(
        (ROOT / "outputs" / "full_v2" / "kinematic_weight_calibration.json").read_text()
    )
    if float(calibration["kinematic_weight"]) != KINEMATIC_WEIGHT:
        raise RuntimeError("Frozen kinematic-weight mismatch")

    manifest = {
        "schema_version": 1,
        "status": "protocol_locked_before_training",
        "protocol_sha256": sha256(PROTOCOL),
        "runner_sha256": sha256(Path(__file__).resolve()),
        "mask_sha256": sha256(MASK),
        "source_hashes": [{"path": str(path), "sha256": sha256(path)} for path in train_sources],
        "folds": list(IRIDIUM_FLIGHTS),
        "variants": VARIANTS,
        "seeds": list(FINAL_SEEDS),
        "kinematic_weight": KINEMATIC_WEIGHT,
        "planned_runs": 75,
        "test_trajectory_files_in_inputs": 0,
        "decision_rule": {
            "contrast": "upper_bound_only minus nn",
            "required_flights_favoring_upper_bound_only": 4,
            "mean_difference_must_be_negative": True,
        },
    }
    manifest["fingerprint"] = object_sha256(manifest)
    atomic_json(OUTPUT / "manifest.json", manifest)

    original_loss = experiment.kinematic_loss
    run_records = []
    try:
        for held_out in IRIDIUM_FLIGHTS:
            fit_rows = [row for row in train_rows if row["flight_id"] != held_out]
            evaluation_rows = [row for row in train_rows if row["flight_id"] == held_out]
            if len(fit_rows) != 27 * 121 or len(evaluation_rows) != 121:
                raise RuntimeError(f"Unexpected fold sizes for {held_out}")
            encoder = Encoder.fit(fit_rows)
            for variant, settings in VARIANTS.items():
                experiment.kinematic_loss = (
                    original_loss
                    if variant != "upper_bound_only"
                    else loss_for(("vertical_rate_le_speed",))
                )
                for seed in FINAL_SEEDS:
                    config = TrainConfig(
                        settings["method"],
                        "final",
                        "005",
                        seed,
                        0.001,
                        0.0001,
                        settings["epochs"],
                    )
                    fingerprint = object_sha256(
                        {
                            "manifest_fingerprint": manifest["fingerprint"],
                            "held_out": held_out,
                            "fit_flights": sorted({row["flight_id"] for row in fit_rows}),
                            "encoder": encoder.as_dict(),
                            "variant": variant,
                            "config": asdict(config),
                        }
                    )
                    run_dir = OUTPUT / held_out / variant / f"seed_{seed}"
                    result = train_one(
                        config,
                        fit_rows,
                        evaluation_rows,
                        encoder,
                        MASK,
                        run_dir,
                        fingerprint,
                        KINEMATIC_WEIGHT,
                    )
                    metric = result["metrics_per_flight"][0]
                    composite = 0.5 * (
                        metric["h_rmse_m"] / encoder.target_scale[0]
                        + metric["v_rmse_m_s"] / encoder.target_scale[1]
                    )
                    run_records.append(
                        {
                            "held_out_flight": held_out,
                            "variant": variant,
                            "seed": seed,
                            "run_directory": str(run_dir.relative_to(ROOT)),
                            "weights_sha256": result["weights_sha256"],
                            "n_observed_rows": result["n_observed_rows"],
                            "n_training_flights": 27,
                            "n_evaluation_rows": result["n_evaluation_rows"],
                            "target_scale": list(encoder.target_scale),
                            "h_rmse_m": metric["h_rmse_m"],
                            "v_rmse_m_s": metric["v_rmse_m_s"],
                            "composite": composite,
                            "kinematic_violation_fraction": result["kinematic_violation_fraction_evaluation"],
                        }
                    )
    finally:
        experiment.kinematic_loss = original_loss

    folds = []
    differences = []
    for held_out in IRIDIUM_FLIGHTS:
        selected = [row for row in run_records if row["held_out_flight"] == held_out]
        variants = {variant: aggregate_fold(selected, variant) for variant in VARIANTS}
        difference = (
            variants["upper_bound_only"]["seed_mean"]["composite"]
            - variants["nn"]["seed_mean"]["composite"]
        )
        differences.append(difference)
        folds.append(
            {
                "held_out_flight": held_out,
                "variants": variants,
                "upper_bound_only_minus_nn": difference,
                "upper_bound_only_favored": difference < 0,
            }
        )
    favor_count = int(sum(value < 0 for value in differences))
    mean_difference = float(np.mean(differences))
    replicated = favor_count >= 4 and mean_difference < 0
    summary = {
        "schema_version": 1,
        "status": "iridium_family_lofo_complete",
        "manifest_fingerprint": manifest["fingerprint"],
        "planned_runs": 75,
        "completed_runs": len(run_records),
        "test_trajectory_files_in_inputs": 0,
        "folds": folds,
        "primary_analysis": {
            "estimand": "five-fold flight-macro composite difference, upper_bound_only minus nn",
            "flight_differences": differences,
            "mean_difference": mean_difference,
            "flights_favoring_upper_bound_only": favor_count,
            "n_flights": 5,
            "decision_rule_passed": replicated,
            "interpretation_if_passed": "internally replicated across original-training Iridium family",
            "interpretation_if_failed": "Iridium NEXT-5 remains flight-specific post-hoc evidence",
        },
        "run_records": run_records,
    }
    atomic_json(OUTPUT / "summary.json", summary)
    print(json.dumps({"status": summary["status"], "completed_runs": len(run_records),
                      "primary_analysis": summary["primary_analysis"]}, indent=2))


if __name__ == "__main__":
    main()
