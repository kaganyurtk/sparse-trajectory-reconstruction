# RQ1 closure update

## Status

RQ1 is closed. Its original primary analysis, held-out test results, model definitions, and
conclusions remain unchanged. No further RQ1 model selection or tuning is warranted.

## Post-hoc work completed after closure

1. Robustness and sensitivity analyses confirmed that the aggregate conclusion is not reversed
   by omitting any single validation or test flight.
2. The Iridium NEXT-5 kinematic-term ablation localized its KC-NN advantage to the
   `dh/dt <= total speed` upper-bound term.
3. A locked Iridium-family leave-one-flight-out replication evaluated whether that localized
   effect generalized to five original-training Iridium flights. It comprised 75 runs: five
   held-out flights, three frozen model variants, and five paired initialization seeds.

## Final replication result

The replication criterion failed. Upper-bound-only KC-NN beat NN on 2/5 flights (NEXT-4 and
NEXT-8), below the locked requirement of at least 4/5. Its unweighted five-flight mean
composite difference was -0.0061, but this average was driven by larger gains on those two
flights and did not represent a flight-consistent family effect.

| Held-out flight | Upper-bound-only minus NN | Winner |
|---|---:|---|
| Iridium NEXT-1 | +0.0169 | NN |
| Iridium NEXT-3 | +0.0371 | NN |
| Iridium NEXT-4 | -0.0573 | Upper-bound-only |
| Iridium NEXT-6 | +0.0146 | NN |
| Iridium NEXT-8 | -0.0416 | Upper-bound-only |

The sign pattern is stable across seeds: upper-bound-only won 5/5 seeds on NEXT-4 and NEXT-8,
1/5 on NEXT-1, and 0/5 on NEXT-3 and NEXT-6. Thus the heterogeneity is not attributable to a
single random initialization.

## Interpretation

The defensible conclusion is local rather than family-wide: a kinematic constraint can help
when it is aligned with a particular trajectory, but it does not produce a uniform predictive
gain. Model-visible inputs are not sufficient to distinguish all mission trajectories. For
example, NEXT-1 and NEXT-4 share Block 3 and a 9,600 kg payload, yet their true 0–120 s
trajectories differ by 731.3 m altitude RMSE and 42.09 m/s speed RMSE. Missing mission and
flight-state covariates create input aliasing, so the same regularizer can help one flight and
hurt another.

## Integrity and handoff

- All 75 planned runs completed and were independently replay-checked.
- Weight hashes, prediction row counts, fold membership, metrics, and decision statistics pass.
- Original held-out RQ1 test trajectory inputs used by this replication: **0**.
- This work is explicitly post-hoc and must not be presented as preregistered primary evidence.
- RQ1 is ready to hand off to RQ2 without further tuning.

Canonical machine-readable evidence is in `outputs/iridium_family_lofo/summary.json` and
`outputs/iridium_family_lofo/verification.json`; the narrative result is in
`IRIDIUM_FAMILY_LOFO_REPORT.md`.
