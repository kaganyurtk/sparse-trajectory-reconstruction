#!/usr/bin/env python3
"""Verify, summarize, and plot the Iridium-family LOFO replication."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from experiment import object_sha256, sha256


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs" / "iridium_family_lofo"
SUMMARY_PATH = OUT / "summary.json"
VERIFY_PATH = OUT / "verification.json"
REPORT_PATH = ROOT / "IRIDIUM_FAMILY_LOFO_REPORT.md"
FIGURE_PNG = ROOT / "figures" / "figure_9_iridium_family_lofo.png"
FIGURE_PDF = ROOT / "figures" / "figure_9_iridium_family_lofo.pdf"
VARIANTS = ("nn", "full_kcnn", "upper_bound_only")


def main():
    manifest = json.loads((OUT / "manifest.json").read_text())
    summary = json.loads(SUMMARY_PATH.read_text())
    manifest_body = dict(manifest)
    saved_fingerprint = manifest_body.pop("fingerprint")
    checks = {
        "manifest_fingerprint": object_sha256(manifest_body) == saved_fingerprint,
        "summary_manifest_link": summary["manifest_fingerprint"] == saved_fingerprint,
        "status_complete": summary["status"] == "iridium_family_lofo_complete",
        "planned_completed_75": summary["planned_runs"] == summary["completed_runs"] == 75,
        "five_folds": len(summary["folds"]) == 5,
        "test_inputs_zero": manifest["test_trajectory_files_in_inputs"] == summary["test_trajectory_files_in_inputs"] == 0,
    }

    observed_pairs = set()
    hashes_ok = predictions_ok = counts_ok = composites_ok = finite_ok = True
    for record in summary["run_records"]:
        run_dir = ROOT / record["run_directory"]
        result = json.loads((run_dir / "result.json").read_text())
        observed_pairs.add((record["held_out_flight"], record["variant"], record["seed"]))
        hashes_ok &= sha256(run_dir / "weights.npz") == result["weights_sha256"] == record["weights_sha256"]
        predictions_ok &= len((run_dir / "evaluation_predictions.csv").read_text().splitlines()) == 122
        counts_ok &= record["n_observed_rows"] == 162 and record["n_training_flights"] == 27 and record["n_evaluation_rows"] == 121
        expected_composite = 0.5 * (
            record["h_rmse_m"] / record["target_scale"][0]
            + record["v_rmse_m_s"] / record["target_scale"][1]
        )
        composites_ok &= abs(expected_composite - record["composite"]) < 1e-14
        finite_ok &= all(
            np.isfinite(record[key])
            for key in ("h_rmse_m", "v_rmse_m_s", "composite", "kinematic_violation_fraction")
        )
    expected_pairs = {
        (flight, variant, seed)
        for flight in manifest["folds"]
        for variant in VARIANTS
        for seed in manifest["seeds"]
    }
    checks.update(
        {
            "all_expected_fold_variant_seed_pairs": observed_pairs == expected_pairs,
            "weights_hashes": bool(hashes_ok),
            "prediction_row_counts": bool(predictions_ok),
            "training_and_evaluation_counts": bool(counts_ok),
            "composite_recalculation": bool(composites_ok),
            "finite_metrics": bool(finite_ok),
        }
    )

    recomputed_differences = []
    for fold in summary["folds"]:
        for variant in VARIANTS:
            source = [
                row for row in summary["run_records"]
                if row["held_out_flight"] == fold["held_out_flight"] and row["variant"] == variant
            ]
            recomputed = float(np.mean([row["composite"] for row in source]))
            checks[f"fold_mean_{fold['held_out_flight']}_{variant}"] = (
                abs(recomputed - fold["variants"][variant]["seed_mean"]["composite"]) < 1e-14
            )
        difference = (
            fold["variants"]["upper_bound_only"]["seed_mean"]["composite"]
            - fold["variants"]["nn"]["seed_mean"]["composite"]
        )
        recomputed_differences.append(difference)
    favor_count = int(sum(value < 0 for value in recomputed_differences))
    mean_difference = float(np.mean(recomputed_differences))
    decision = favor_count >= 4 and mean_difference < 0
    checks["primary_flight_differences"] = np.allclose(
        recomputed_differences, summary["primary_analysis"]["flight_differences"], atol=1e-14, rtol=0
    )
    checks["primary_mean_difference"] = abs(mean_difference - summary["primary_analysis"]["mean_difference"]) < 1e-14
    checks["primary_favor_count"] = favor_count == summary["primary_analysis"]["flights_favoring_upper_bound_only"]
    checks["decision_rule"] = decision == summary["primary_analysis"]["decision_rule_passed"]

    status = "passed" if all(checks.values()) else "failed"
    verification = {
        "status": status,
        "checks": checks,
        "verified_runs": len(observed_pairs),
        "recomputed_primary": {
            "flight_differences": recomputed_differences,
            "mean_difference": mean_difference,
            "flights_favoring_upper_bound_only": favor_count,
            "decision_rule_passed": decision,
        },
    }
    VERIFY_PATH.write_text(json.dumps(verification, indent=2) + "\n")
    if status != "passed":
        raise RuntimeError(verification)

    labels = ["NEXT-1", "NEXT-3", "NEXT-4", "NEXT-6", "NEXT-8"]
    colors = {"nn": "#d95f02", "full_kcnn": "#1b9e77", "upper_bound_only": "#377eb8"}
    display = {"nn": "NN", "full_kcnn": "Full KC-NN", "upper_bound_only": "Upper-bound only"}
    x = np.arange(len(labels))
    width = 0.24
    fig, ax = plt.subplots(figsize=(11, 6.5), constrained_layout=True)
    for offset, variant in zip((-width, 0, width), VARIANTS):
        means = [fold["variants"][variant]["seed_mean"]["composite"] for fold in summary["folds"]]
        errors = [fold["variants"][variant]["seed_sd_descriptive"]["composite"] for fold in summary["folds"]]
        ax.bar(x + offset, means, width, yerr=errors, capsize=3, label=display[variant], color=colors[variant], alpha=0.9)
    ax.set_xticks(x, labels)
    ax.set_ylabel("Standardized composite error (lower is better)")
    ax.set_title("Iridium-family leave-one-flight-out replication at 5% observations")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(frameon=False, ncol=3)
    FIGURE_PNG.parent.mkdir(exist_ok=True)
    fig.savefig(FIGURE_PNG, dpi=220)
    fig.savefig(FIGURE_PDF)
    plt.close(fig)

    model_means = {
        variant: float(np.mean([
            fold["variants"][variant]["seed_mean"]["composite"] for fold in summary["folds"]
        ]))
        for variant in VARIANTS
    }
    table_rows = []
    for fold in summary["folds"]:
        table_rows.append(
            "| {name} | {nn:.4f} | {full:.4f} | {upper:.4f} | {diff:+.4f} | {favored} |".format(
                name=fold["held_out_flight"].replace("iridium_next_", "NEXT-"),
                nn=fold["variants"]["nn"]["seed_mean"]["composite"],
                full=fold["variants"]["full_kcnn"]["seed_mean"]["composite"],
                upper=fold["variants"]["upper_bound_only"]["seed_mean"]["composite"],
                diff=fold["upper_bound_only_minus_nn"],
                favored="Upper" if fold["upper_bound_only_favored"] else "NN",
            )
        )

    next1 = pd.read_csv(ROOT / "data" / "flights" / "iridium_next_1.csv")
    next4 = pd.read_csv(ROOT / "data" / "flights" / "iridium_next_4.csv")
    pair_h = float(np.sqrt(np.mean((next1.altitude_m - next4.altitude_m) ** 2)))
    pair_v = float(np.sqrt(np.mean((next1.speed_m_s - next4.speed_m_s) ** 2)))
    report = f"""# Iridium-family leave-one-flight-out replication report

## Outcome

The locked family-level decision rule **failed**. The upper-bound-only model beat NN on
{favor_count}/5 held-out Iridium flights; at least 4/5 were required. Its five-flight mean
difference was {mean_difference:+.4f}, which was negative only because the gains on NEXT-4
and NEXT-8 were larger than the losses on the other three flights. This does not support a
family-wide Iridium effect.

| Held-out flight | NN | Full KC-NN | Upper-bound only | Upper minus NN | Favored |
|---|---:|---:|---:|---:|---|
{chr(10).join(table_rows)}

Across the five held-out flights, the unweighted mean composite errors were
{model_means['nn']:.4f} (NN), {model_means['full_kcnn']:.4f} (full KC-NN), and
{model_means['upper_bound_only']:.4f} (upper-bound only). The upper-bound-only mean is lowest,
but the benefit is not flight-consistent and therefore does not pass the prespecified rule.

## Seed consistency

Upper-bound only beat NN for all five seeds on NEXT-4 and NEXT-8, for one of five seeds on
NEXT-1, and for zero of five seeds on NEXT-3 and NEXT-6. The heterogeneous flight result is
therefore not caused by a single initialization.

## Mechanistic interpretation

The model inputs cannot uniquely identify an Iridium trajectory. NEXT-1 and NEXT-4 have the
same model-visible static inputs (Block 3 and 9,600 kg payload), yet their true trajectories
differ by {pair_h:.1f} m altitude RMSE and {pair_v:.2f} m/s speed RMSE over 0–120 s. Mission
identity, orbit details, landing mode, and other flight-specific state are not supplied to the
network. A shared physical regularizer can move the prediction toward one member of such an
input-equivalent pair while moving it away from another.

## Scientific conclusion

The earlier Iridium NEXT-5 benefit remains a valid flight-level mechanism observation, but it
does not generalize to the Iridium family under the locked 4/5 criterion. The defensible RQ1
conclusion remains that physics constraints provide heterogeneous, locally aligned benefits
rather than a uniform accuracy improvement. This replication is post-hoc relative to RQ1 and
must not be presented as part of the preregistered primary analysis.
"""
    REPORT_PATH.write_text(report)
    print(json.dumps(verification, indent=2))


if __name__ == "__main__":
    main()
