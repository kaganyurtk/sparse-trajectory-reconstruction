#!/usr/bin/env python3
"""Run the locked post-hoc three-term KC-NN ablation at the 5% mask."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch

import experiment
from evaluate_test import load_test
from experiment import (
    FINAL_SEEDS,
    Encoder,
    TrainConfig,
    atomic_json,
    flight_metrics,
    load_flights,
    load_npz_model,
    object_sha256,
    selection_score,
    sha256,
    targets,
    train_one,
    write_predictions,
)


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "outputs" / "kinematic_term_ablation"
PROTOCOL = ROOT / "KINEMATIC_TERM_ABLATION_PROTOCOL.md"
MASK = ROOT / "data" / "fractions" / "train_005pct.csv"
KINEMATIC_WEIGHT = 33.6822579609781
VARIANTS = {
    "omit_vertical_rate_nonnegative": ("vertical_rate_le_speed", "speed_nonnegative"),
    "omit_vertical_rate_le_speed": ("vertical_rate_nonnegative", "speed_nonnegative"),
    "omit_speed_nonnegative": ("vertical_rate_nonnegative", "vertical_rate_le_speed"),
}


def component_tensors(model, x, target_mean, target_scale):
    x_grad = x.detach().clone().requires_grad_(True)
    pred_std = model(x_grad)
    altitude = target_mean[0] + target_scale[0] * pred_std[:, 0]
    speed = target_mean[1] + target_scale[1] * pred_std[:, 1]
    vertical_rate = torch.autograd.grad(altitude.sum(), x_grad, create_graph=True)[0][:, 0] / 120.0
    scale = target_scale[1]
    return {
        "vertical_rate_nonnegative": torch.relu(-vertical_rate / scale),
        "vertical_rate_le_speed": torch.relu((vertical_rate - speed) / scale),
        "speed_nonnegative": torch.relu(-speed / scale),
    }, vertical_rate, speed


def loss_for(active_terms):
    active_terms = tuple(active_terms)

    def variant_loss(model, collocation_x, target_mean, target_scale):
        components, vertical_rate, speed = component_tensors(
            model, collocation_x, target_mean, target_scale
        )
        active = [components[name] for name in active_terms]
        loss = torch.stack([value.square() for value in active], dim=0).sum(dim=0).mean()
        violation = torch.stack([value > 0 for value in active], dim=0).any(dim=0)
        return loss, {"vertical_rate": vertical_rate, "speed": speed, "violation": violation}

    return variant_loss


def all_component_diagnostics(model, x, encoder):
    components, _, _ = component_tensors(model, x, encoder.target_mean, encoder.target_scale)
    return {
        name: {
            "mean_squared_hinge": float(value.square().mean().detach()),
            "active_fraction": float((value > 0).double().mean().detach()),
        }
        for name, value in components.items()
    }


def existing_iridium_comparators(encoder):
    summary = json.loads((ROOT / "outputs" / "test_v2" / "summary_corrected.json").read_text())
    result = {}
    for method in ("nn", "kcnn"):
        rows = []
        for run in summary["test_results"]:
            config = run["config"]
            if config["fraction"] != "005" or config["method"] != method:
                continue
            metric = next(item for item in run["metrics_per_flight"] if item["flight_id"] == "iridium_next_5")
            rows.append(
                {
                    "seed": config["seed"],
                    "h_rmse_m": metric["h_rmse_m"],
                    "v_rmse_m_s": metric["v_rmse_m_s"],
                    "composite": 0.5
                    * (
                        metric["h_rmse_m"] / encoder.target_scale[0]
                        + metric["v_rmse_m_s"] / encoder.target_scale[1]
                    ),
                }
            )
        result[method] = {
            "seed_records": sorted(rows, key=lambda row: row["seed"]),
            "seed_mean": {
                key: float(np.mean([row[key] for row in rows]))
                for key in ("h_rmse_m", "v_rmse_m_s", "composite")
            },
        }
    return result


def main():
    if not PROTOCOL.is_file():
        raise FileNotFoundError(PROTOCOL)
    train_rows, validation_rows, _ = load_flights(ROOT / "data" / "flights")
    test_rows, _ = load_test(ROOT / "data" / "test_flights")
    encoder = Encoder.fit(train_rows)
    full_manifest = json.loads((ROOT / "outputs" / "full_v2" / "run_manifest.json").read_text())
    if encoder.as_dict() != full_manifest["encoders"]["final"]:
        raise RuntimeError("Frozen final encoder mismatch")
    calibration = json.loads(
        (ROOT / "outputs" / "full_v2" / "kinematic_weight_calibration.json").read_text()
    )
    if float(calibration["kinematic_weight"]) != KINEMATIC_WEIGHT:
        raise RuntimeError("Kinematic-weight mismatch")

    x_test = torch.tensor(encoder.transform(test_rows), dtype=torch.float64)
    y_test = targets(test_rows)
    manifest = {
        "schema_version": 1,
        "status": "post_hoc_protocol_locked_before_ablation_training",
        "protocol_sha256": sha256(PROTOCOL),
        "mask_sha256": sha256(MASK),
        "base_global_fingerprint": full_manifest["global_fingerprint"],
        "variants": VARIANTS,
        "seeds": list(FINAL_SEEDS),
        "config": {
            "fraction": "005",
            "learning_rate": 0.001,
            "weight_decay": 0.0001,
            "epochs": 400,
            "kinematic_weight": KINEMATIC_WEIGHT,
        },
        "train_flights": sorted({row["flight_id"] for row in train_rows}),
        "validation_flights": sorted({row["flight_id"] for row in validation_rows}),
        "test_flights": sorted({row["flight_id"] for row in test_rows}),
        "test_use": "post_hoc_descriptive_mechanism_analysis_no_tuning",
    }
    manifest["fingerprint"] = object_sha256(manifest)
    atomic_json(OUTPUT / "manifest.json", manifest)

    original_loss = experiment.kinematic_loss
    runs = []
    try:
        for variant, active_terms in VARIANTS.items():
            experiment.kinematic_loss = loss_for(active_terms)
            for seed in FINAL_SEEDS:
                config = TrainConfig("kcnn", "final", "005", seed, 0.001, 0.0001, 400)
                fingerprint = object_sha256(
                    {
                        "ablation_manifest": manifest["fingerprint"],
                        "variant": variant,
                        "active_terms": active_terms,
                        "config": asdict(config),
                    }
                )
                run_dir = OUTPUT / variant / f"seed_{seed}"
                validation_result = train_one(
                    config,
                    train_rows,
                    validation_rows,
                    encoder,
                    MASK,
                    run_dir,
                    fingerprint,
                    KINEMATIC_WEIGHT,
                )
                model = load_npz_model(run_dir / "weights.npz")
                with torch.no_grad():
                    prediction = encoder.inverse_targets(model(x_test).numpy())
                metrics = flight_metrics(test_rows, y_test, prediction)
                test_result = {
                    "variant": variant,
                    "active_terms": list(active_terms),
                    "seed": seed,
                    "weights_sha256": validation_result["weights_sha256"],
                    "validation_evaluation_score": validation_result["evaluation_score"],
                    "test_evaluation_score": selection_score(metrics, encoder.target_scale),
                    "test_metrics_per_flight": metrics,
                    "test_component_diagnostics": all_component_diagnostics(model, x_test, encoder),
                }
                write_predictions(run_dir / "test_predictions.csv", test_rows, y_test, prediction)
                atomic_json(run_dir / "test_result.json", test_result)
                runs.append(test_result)
    finally:
        experiment.kinematic_loss = original_loss

    summary = {
        "schema_version": 1,
        "status": "post_hoc_kinematic_term_ablation_complete",
        "manifest_fingerprint": manifest["fingerprint"],
        "planned_runs": 15,
        "completed_runs": len(runs),
        "training_or_tuning_on_test": False,
        "comparators": existing_iridium_comparators(encoder),
        "variants": {},
        "runs": runs,
    }
    for variant in VARIANTS:
        selected = [run for run in runs if run["variant"] == variant]
        iridium = []
        for run in selected:
            metric = next(
                item for item in run["test_metrics_per_flight"] if item["flight_id"] == "iridium_next_5"
            )
            iridium.append(
                {
                    "seed": run["seed"],
                    "h_rmse_m": metric["h_rmse_m"],
                    "v_rmse_m_s": metric["v_rmse_m_s"],
                    "composite": 0.5
                    * (
                        metric["h_rmse_m"] / encoder.target_scale[0]
                        + metric["v_rmse_m_s"] / encoder.target_scale[1]
                    ),
                }
            )
        summary["variants"][variant] = {
            "active_terms": list(VARIANTS[variant]),
            "iridium_seed_records": sorted(iridium, key=lambda row: row["seed"]),
            "iridium_seed_mean": {
                key: float(np.mean([row[key] for row in iridium]))
                for key in ("h_rmse_m", "v_rmse_m_s", "composite")
            },
            "all_test_flight_macro_composite_seed_mean": float(
                np.mean([run["test_evaluation_score"] for run in selected])
            ),
            "outer_validation_flight_macro_composite_seed_mean": float(
                np.mean([run["validation_evaluation_score"] for run in selected])
            ),
        }
    atomic_json(OUTPUT / "summary.json", summary)
    print(json.dumps({"status": summary["status"], "completed_runs": len(runs),
                      "comparators": summary["comparators"], "variants": summary["variants"]}, indent=2))


if __name__ == "__main__":
    main()
