# RQ1 figure captions

**Figure 1. Predictive error under increasingly sparse observations.** Flight-macro
standardized composite error for the data-driven neural network (NN) and kinematically
constrained neural network (KC-NN) on outer-validation and held-out test flights. Lines show
the mean across five paired initialization seeds; shaded regions show ±1 seed standard
deviation and are descriptive rather than confidence intervals. Lower values are better.

**Figure 2. Held-out test accuracy–constraint trade-off.** Flight-macro altitude RMSE,
speed RMSE, and kinematic violation fraction across observation rates. Points show the mean
across five paired seeds and error bars show ±1 seed standard deviation. KC-NN consistently
reduces altitude error and kinematic violations but increases speed error.

**Figure 3. Flight-level effect at 5% observations.** Difference in five-seed-averaged
standardized composite error between KC-NN and NN for each outer-validation and held-out test
flight. Negative values (green) favor KC-NN; positive values (red) favor NN. KC-NN improves
only Iridium NEXT-5 in the held-out test set.

**Figure 4. Leave-one-flight-out sensitivity at 5% observations.** Each bar shows the
remaining-flight mean difference in standardized composite error (KC-NN minus NN) after the
named flight is omitted; the dashed line is the corresponding all-flight mean. Positive values
favor NN. The sign remains positive for every omission in both outer validation and held-out
test, so no single flight reverses the primary conclusion.

**Figure 5. Seed-level sensitivity at 5% observations.** Paired difference in flight-macro
standardized composite error (KC-NN minus NN) for each frozen initialization seed; the dashed
line is the five-seed mean. Positive values (red) favor NN and negative values (green) favor
KC-NN. Four of five seeds favor NN in each split. Seeds are paired repeated initializations and
are shown descriptively, not as independent inferential samples.

**Figure 6. Iridium NEXT-5 trajectories at 5% training observations.** True altitude and
speed compared with five-seed mean NN and KC-NN predictions; shaded bands show ±1 seed
standard deviation. The unconstrained NN overshoots the middle and late altitude trajectory,
whereas KC-NN substantially reduces that error. Bands are descriptive, not confidence
intervals.

**Figure 7. Iridium NEXT-5 sensitivity to training observation rate.** Five-seed mean
standardized composite error for NN and KC-NN at each frozen observation mask. Lower values
are better. KC-NN is better at every observation rate, and the gap is largest at 5%.

**Figure 8. Post-hoc kinematic-term ablation on Iridium NEXT-5.** Five-seed mean
standardized composite error at the frozen 5% observation mask; error bars show ±1 seed
standard deviation and are descriptive. Removing the `dh/dt <= speed` hinge eliminates the
KC-NN advantage and performs worse than NN. Removing the nonnegative-speed hinge is
numerically equivalent to full KC-NN. This mechanism analysis was specified and run after RQ1
was closed and is not part of the preregistered primary analysis.
