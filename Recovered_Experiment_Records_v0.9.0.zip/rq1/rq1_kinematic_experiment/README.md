# RQ1 NN–KC-NN karşılaştırma kodu

Bu klasör, dondurulmuş `RQ1_EXPERIMENT_PROTOCOL.md` protokolünü uygular. İki yöntem de
aynı 32×32 `tanh` ağı, girdileri, başlangıç ağırlıklarını ve ayarlama bütçesini kullanır.
KC-NN'nin tek yöntem farkı fiziksel olarak geçerli `0 <= dh/dt <= v` cezasıdır.

Sürüm 2 akışı 28 train uçuşunu sabit 22 inner-fit / 6 inner-validation olarak ayırır.
Mevcut altı validation uçuşu outer-validation'dır ve yalnızca yöntemler dondurulduktan
sonra değerlendirilir. Birincil sonuç önceden `%5` outer-validation birleşik hatasıdır.

## Güvenlik sınırları

- `data/flights/` yalnızca 28 train ve 6 validation dosyası içerir.
- Altı test uçuşu indirilmez; loader bir test uçuşu görürse hata verir.
- Seyrek maskede bulunmayan hedefler veri kaybına girmez.
- Collocation hesabı yalnızca zaman ve ilgili fit bölümünün metadata girdilerini kullanır.
- KC-NN ağırlığı outer-validation kullanılmadan train-only başlangıç gradyan normlarından hesaplanır.
- Kod, protokol, split, maskeler ve veri dosyaları SHA-256 manifestiyle kilitlenir.
- Resume yalnız fingerprint ile ağırlık özeti birebir uyuştuğunda kabul edilir.
- Smoke çıktıları bilimsel sonuç değildir.

## Ortam

CPU PyTorch kurulumu:

```bash
python -m pip install --index-url https://download.pytorch.org/whl/cpu \
  'torch==2.7.1+cpu'
```

## Kontroller ve smoke test

```bash
PYTHONPATH="../.deps:$PWD" python test_experiment.py
PYTHONPATH="../.deps:$PWD" python run_experiment.py --mode smoke --smoke-epochs 5 \
  --protocol ../RQ1_EXPERIMENT_PROTOCOL.md
PYTHONPATH="../.deps:$PWD" python verify_outputs.py
```

Smoke testi %5 maskesinde seed 11 ile bir NN ve bir KC-NN çalıştırır. Tam deney komutu,
validation raporu ve kod incelemesi tamamlandıktan sonra kullanılmalıdır:

```bash
PYTHONPATH="../.deps:$PWD" python run_experiment.py --mode full \
  --protocol ../RQ1_EXPERIMENT_PROTOCOL.md
```

Kod Drive'daki `outputs/rq1_kinematic_experiment` klasöründen yerel proje yapısına
alınırsa mevcut işlenmiş veriye açıkça yol verilebilir:

```bash
python outputs/rq1_kinematic_experiment/run_experiment.py \
  --root outputs/rq1_kinematic_experiment \
  --data-root outputs/rq1_preprocessing_pipeline/processed \
  --protocol RQ1_EXPERIMENT_PROTOCOL.md \
  --mode smoke
```

Tam çalışma kesilirse tamamlanmış `result.json` koşuları yeniden eğitilmeden kullanılır.
Tam plan 48 inner tarama + 50 final refit olmak üzere 98 benzersiz eğitimdir. Beş seed
önce her uçuş içinde ortalanır; `%5` birincil fark için altı uçuş 10.000 tekrarlı sabit-seed
bootstrap birimidir. Test değerlendirmesi bu kodun kapsamına dahil değildir.
