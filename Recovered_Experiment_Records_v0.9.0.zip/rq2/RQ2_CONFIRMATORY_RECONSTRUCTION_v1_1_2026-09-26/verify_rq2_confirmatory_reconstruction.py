#!/usr/bin/env python3
"""Independent replay checks for the RQ2 reconstruction-v1 run."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np

import run_rq2_confirmatory_reconstruction as run


def main() -> None:
    out = run.OUT
    manifest = json.loads((out / "manifest.json").read_text())
    results = json.loads((out / "results.json").read_text())

    unhashed = {k: v for k, v in manifest.items() if k != "fingerprint"}
    fingerprint = hashlib.sha256(json.dumps(unhashed, sort_keys=True).encode()).hexdigest()

    man, fit_groups, val_groups, test_groups = run.snapshot_and_groups()
    flights, xm, xs, ym, ys = run.prepare(man)
    ids = {
        split: list(man[(man.split == split) & man.flight_id.isin(flights)].flight_id.astype(int))
        for split in ("fit", "inner_validation", "test")
    }
    test = run.stack(flights, ids["test"])
    flight_map = dict(zip(man.flight_id.astype(int), man.operational_group))

    replay = []
    exact = True
    model_hashes = {}
    for expected in results["results"]:
        seed, method = expected["seed"], expected["method"]
        path = out / f"{method}_seed_{seed}.npz"
        model_hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
        saved = np.load(path)
        net = run.Net(seed)
        net.p = [saved[f"arr_{i}"] for i in range(6)]
        got = run.metrics(net, test, ym, ys, flight_map)
        delta = {k: abs(got[k] - expected[k]) for k in ("h_rmse_m", "v_rmse_m_s", "score")}
        exact &= max(delta.values()) < 1e-12
        replay.append({"seed": seed, "method": method, "absolute_differences": delta})

    split_sets = [set(fit_groups), set(val_groups), set(test_groups)]
    disjoint = all(split_sets[i].isdisjoint(split_sets[j]) for i in range(3) for j in range(i + 1, 3))
    checks = {
        "manifest_fingerprint_recomputed": fingerprint,
        "manifest_fingerprint_matches": fingerprint == manifest["fingerprint"] == results["manifest_fingerprint"],
        "split_groups_pairwise_disjoint": disjoint,
        "test_group_count": len(test_groups),
        "test_flight_count": len(ids["test"]),
        "test_ids_match_manifest": ids["test"] == manifest["test_flight_ids"],
        "scales_match_manifest": bool(
            np.allclose(xm, manifest["scales"]["x_mean"], atol=0, rtol=0)
            and np.allclose(xs, manifest["scales"]["x_std"], atol=0, rtol=0)
            and np.allclose(ym, manifest["scales"]["y_mean"], atol=0, rtol=0)
            and np.allclose(ys, manifest["scales"]["y_std"], atol=0, rtol=0)
        ),
        "all_saved_model_metrics_exact": bool(exact),
        "model_sha256": model_hashes,
        "replay": replay,
    }
    checks["all_checks_passed"] = all(
        [
            checks["manifest_fingerprint_matches"],
            checks["split_groups_pairwise_disjoint"],
            checks["test_group_count"] == 8,
            checks["test_flight_count"] == 46,
            checks["test_ids_match_manifest"],
            checks["scales_match_manifest"],
            checks["all_saved_model_metrics_exact"],
        ]
    )
    (out / "verification.json").write_text(json.dumps(checks, indent=2, sort_keys=True))
    print(json.dumps({k: checks[k] for k in checks if k not in {"model_sha256", "replay"}}, indent=2))
    if not checks["all_checks_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
