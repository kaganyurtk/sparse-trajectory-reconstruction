#!/usr/bin/env python3
from __future__ import annotations

import hashlib, json, math
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "tmp/rq2_rebuild/audit/raw_private"
OLD_MANIFEST = ROOT / "tmp/rq2_curation_inspect/outputs/flightsketch_audit/rq2_candidate_manifest.csv"
IDENTITY = Path("/workspace/scratch/b4b09bd229df/attachments/afaa15ac-f82c-4cdd-b981-b9cb267eb395/RQ2_IDENTITY_DECISION_REGISTER_v2_2026-09-23.xlsx")
OUT = ROOT / "tmp/rq2_confirmatory_v1_1"
SEEDS = (11, 29, 47, 71, 97)
TEST_SEED = "rq2-confirmatory-reconstruction-v1"
INNER_SEED = "rq2-confirmatory-reconstruction-v1-inner"
MASK_SEED = "rq2-confirmatory-reconstruction-v1-mask"
FT_TO_M = 0.3048
FRACTION = 0.05
LAMBDA_PHYS = 1.91

def sha(s: str) -> str: return hashlib.sha256(s.encode()).hexdigest()

def snapshot_and_groups():
    man = pd.read_csv(OLD_MANIFEST)
    reg = pd.read_excel(IDENTITY, sheet_name="Decision Register")
    reg = reg[reg.operational_decision != "exclude_nonidentifying_title"].copy()
    grouped = reg.groupby("canonical_operational_group_id", sort=True).agg(
        source_keys=("vehicle_key", lambda s: list(s)),
        uploader=("uploader", "first"),
        possible_development=("development_membership_evidence", lambda s: any(
            "consistent_with_41_group_count_rule" in str(x) and "not_consistent" not in str(x) for x in s
        )),
    ).reset_index()
    key_to_opg = {}
    for row in grouped.itertuples():
        for key in row.source_keys: key_to_opg[key] = row.canonical_operational_group_id
    man = man[man.vehicle_key.isin(key_to_opg)].copy()
    man["operational_group"] = man.vehicle_key.map(key_to_opg)
    usable=[]
    for row in man.itertuples():
        p=RAW/f"flight_{int(row.flight_id)}.csv"
        if not p.exists(): continue
        z=pd.read_csv(p, usecols=lambda c:c in {"time","altitude","velocity"})
        if pd.to_numeric(z.velocity,errors="coerce").min() < -500: continue
        usable.append(int(row.flight_id))
    man=man[man.flight_id.isin(usable)].copy()
    dev_groups=set(grouped.loc[grouped.possible_development,"canonical_operational_group_id"])
    candidates=grouped[~grouped.possible_development].copy()
    candidates["order"]=candidates.canonical_operational_group_id.map(lambda x:sha(f"{TEST_SEED}::{x}"))
    test_groups=list(candidates.sort_values("order").head(8).canonical_operational_group_id)
    dev=grouped[grouped.canonical_operational_group_id.isin(dev_groups)].copy()
    dev["order"]=dev.canonical_operational_group_id.map(lambda x:sha(f"{INNER_SEED}::{x}"))
    val_groups=list(dev.sort_values("order").head(6).canonical_operational_group_id)
    fit_groups=sorted(dev_groups-set(val_groups))
    man["split"]=np.where(man.operational_group.isin(test_groups),"test",np.where(man.operational_group.isin(val_groups),"inner_validation",np.where(man.operational_group.isin(fit_groups),"fit","unused")))
    return man, fit_groups, val_groups, test_groups

def grid_flight(fid:int):
    z=pd.read_csv(RAW/f"flight_{fid}.csv")[["time","altitude","velocity"]].apply(pd.to_numeric,errors="coerce").dropna().sort_values("time")
    z=z.drop_duplicates("time")
    t=z.time.to_numpy(float); h=z.altitude.to_numpy(float)*FT_TO_M; v=z.velocity.to_numpy(float)*FT_TO_M
    lo=math.ceil(t.min()); hi=math.floor(t.max())
    if hi-lo<3: return None
    g=np.arange(lo,hi+1,dtype=float); hg=np.interp(g,t,h); vg=np.interp(g,t,v); rel=g-g[0]; dur=max(rel[-1],1.)
    n=len(g); k=max(2,int(math.ceil(FRACTION*n))); obs={0,n-1}
    order=sorted(range(1,n-1),key=lambda i:sha(f"{MASK_SEED}::{fid}::{i}"))
    obs.update(order[:max(0,k-2)]); oi=np.array(sorted(obs),int)
    hs=np.interp(np.arange(n),oi,hg[oi]); vs=np.interp(np.arange(n),oi,vg[oi])
    dist=np.min(np.abs(np.arange(n)[:,None]-oi[None,:]),axis=1)/dur
    flag=np.zeros(n); flag[oi]=1
    X=np.c_[2*rel/dur-1,hs,vs,dist,np.full(n,dur),flag,np.full(n,np.log(FRACTION))]
    Y=np.c_[hg,vg]
    return {"fid":fid,"t":rel,"X":X,"Y":Y}

def prepare(man):
    flights={}
    for fid in man[man.split!="unused"].flight_id.astype(int):
        q=grid_flight(fid)
        if q is not None: flights[fid]=q
    fit_ids=list(man[(man.split=="fit") & man.flight_id.isin(flights)].flight_id.astype(int))
    xfit=np.vstack([flights[i]["X"] for i in fit_ids]); yfit=np.vstack([flights[i]["Y"] for i in fit_ids])
    xm=xfit.mean(0); xs=xfit.std(0); xs[xs<1e-8]=1
    ym=yfit.mean(0); ys=yfit.std(0); ys[ys<1e-8]=1
    for q in flights.values(): q["Xs"]=(q["X"]-xm)/xs; q["Ys"]=(q["Y"]-ym)/ys
    return flights,xm,xs,ym,ys

def stack(flights,ids):
    X=[];Y=[];edges_i=[];edges_j=[];dts=[];groups=[];off=0
    for fid in ids:
        q=flights[fid];n=len(q["t"]);X.append(q["Xs"]);Y.append(q["Ys"])
        edges_i.extend(range(off,off+n-1));edges_j.extend(range(off+1,off+n));dts.extend(np.diff(q["t"]));groups.extend([fid]*n);off+=n
    return np.vstack(X),np.vstack(Y),np.array(edges_i),np.array(edges_j),np.array(dts),np.array(groups)

class Net:
    def __init__(self,seed,d=7):
        r=np.random.default_rng(seed)
        self.p=[r.normal(0,np.sqrt(2/(d+32)),(d,32)),np.zeros(32),r.normal(0,np.sqrt(2/64),(32,32)),np.zeros(32),r.normal(0,np.sqrt(2/34),(32,2)),np.zeros(2)]
    def forward(self,X):
        W1,b1,W2,b2,W3,b3=self.p;a1=np.tanh(X@W1+b1);a2=np.tanh(a1@W2+b2);y=a2@W3+b3;return y,(X,a1,a2)
    def grad(self,cache,dy):
        X,a1,a2=cache;W1,b1,W2,b2,W3,b3=self.p
        gW3=a2.T@dy;gb3=dy.sum(0);da2=dy@W3.T;dz2=da2*(1-a2*a2);gW2=a1.T@dz2;gb2=dz2.sum(0);da1=dz2@W2.T;dz1=da1*(1-a1*a1);gW1=X.T@dz1;gb1=dz1.sum(0)
        return [gW1,gb1,gW2,gb2,gW3,gb3]

def loss_grad(net,X,Y,ei,ej,dt,ys,physics):
    pred,c=net.forward(X);dy=(pred-Y)/len(X);data=float(np.mean((pred-Y)**2))
    phys=0.
    if physics and len(ei):
        h=pred[:,0]*ys[0];v=pred[:,1]*ys[1];res=((h[ej]-h[ei])/dt-.5*(v[ei]+v[ej]))/ys[1];phys=float(np.mean(res**2));dr=2*res/len(res);pg=np.zeros_like(pred)
        np.add.at(pg[:,0],ei,dr*(-ys[0]/dt/ys[1]));np.add.at(pg[:,0],ej,dr*(ys[0]/dt/ys[1]));np.add.at(pg[:,1],ei,dr*(-.5));np.add.at(pg[:,1],ej,dr*(-.5));dy+=LAMBDA_PHYS*pg
    return data+LAMBDA_PHYS*phys, data, phys, net.grad(c,dy)

def train(seed,physics,tr,va,ys,max_epochs=3000,patience=250):
    net=Net(seed);m=[np.zeros_like(x) for x in net.p];v=[np.zeros_like(x) for x in net.p];best=None;bestval=float('inf');wait=0;lr=1e-3;wd=1e-4
    X,Y,ei,ej,dt,_=tr;Xv,Yv,*_=va
    for ep in range(1,max_epochs+1):
        total,data,pl,gr=loss_grad(net,X,Y,ei,ej,dt,ys,physics)
        for k,(p,g) in enumerate(zip(net.p,gr)):
            g=g+wd*p;m[k]=.9*m[k]+.1*g;v[k]=.999*v[k]+.001*(g*g);mh=m[k]/(1-.9**ep);vh=v[k]/(1-.999**ep);p-=lr*mh/(np.sqrt(vh)+1e-8)
        pv,_=net.forward(Xv);val=float(np.mean((pv-Yv)**2))
        if val<bestval-1e-8:bestval=val;best=[x.copy() for x in net.p];wait=0
        else:wait+=1
        if wait>=patience:break
    net.p=best
    return net,{"epochs":ep,"best_val_mse":bestval}

def metrics(net,data,ym,ys,flight_map):
    X,Y,ei,ej,dt,fids=data;p,_=net.forward(X);yp=p*ys+ym;yt=Y*ys+ym
    h=float(np.sqrt(np.mean((yp[:,0]-yt[:,0])**2)));v=float(np.sqrt(np.mean((yp[:,1]-yt[:,1])**2)));score=.5*(h/ys[0]+v/ys[1])
    by={}
    for fid in np.unique(fids):
        ix=fids==fid;hh=float(np.sqrt(np.mean((yp[ix,0]-yt[ix,0])**2)));vv=float(np.sqrt(np.mean((yp[ix,1]-yt[ix,1])**2)));by[int(fid)]={"h_rmse_m":hh,"v_rmse_m_s":vv,"score":.5*(hh/ys[0]+vv/ys[1]),"group":flight_map[int(fid)]}
    return {"h_rmse_m":h,"v_rmse_m_s":v,"score":score,"by_flight":by}

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    man,fitg,valg,testg=snapshot_and_groups();flights,xm,xs,ym,ys=prepare(man)
    ids={s:list(man[(man.split==s)&man.flight_id.isin(flights)].flight_id.astype(int)) for s in ["fit","inner_validation","test"]}
    flight_map=dict(zip(man.flight_id.astype(int),man.operational_group));tr=stack(flights,ids["fit"]);va=stack(flights,ids["inner_validation"]);te=stack(flights,ids["test"])
    manifest={"protocol":TEST_SEED,"run_revision":"1.1","method":{"optimizer":"Adam","learning_rate":1e-3,"coupled_l2_weight_decay":1e-4,"max_epochs":3000,"patience":250,"hidden_layers":[32,32],"activation":"tanh","physics_weight":LAMBDA_PHYS,"observation_fraction":FRACTION,"seeds":list(SEEDS)},"fit_groups":fitg,"inner_validation_groups":valg,"test_groups":testg,"counts":{k:{"flights":len(v),"rows":int(sum(len(flights[i]['t']) for i in v))} for k,v in ids.items()},"test_flight_ids":ids['test'],"scales":{"x_mean":xm.tolist(),"x_std":xs.tolist(),"y_mean":ym.tolist(),"y_std":ys.tolist()}}
    raw=json.dumps(manifest,sort_keys=True).encode();manifest["fingerprint"]=hashlib.sha256(raw).hexdigest();(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True));man.to_csv(OUT/'flight_split_manifest.csv',index=False)
    results=[]
    for seed in SEEDS:
        for name,phys in [("nn",False),("kcnn",True)]:
            net,info=train(seed,phys,tr,va,ys);met=metrics(net,te,ym,ys,flight_map);results.append({"seed":seed,"method":name,**info,**met});np.savez_compressed(OUT/f'{name}_seed_{seed}.npz',*net.p)
            print(json.dumps({"seed":seed,"method":name,"epochs":info['epochs'],"score":met['score'],"h":met['h_rmse_m'],"v":met['v_rmse_m_s']}),flush=True)
    pairs=[]
    for seed in SEEDS:
        a=next(x for x in results if x['seed']==seed and x['method']=='nn');b=next(x for x in results if x['seed']==seed and x['method']=='kcnn');pairs.append({"seed":seed,"nn":a['score'],"kcnn":b['score'],"difference":b['score']-a['score']})
    ds=np.array([x['difference'] for x in pairs]);summary={"manifest_fingerprint":manifest['fingerprint'],"pairs":pairs,"mean_difference":float(ds.mean()),"sd_difference":float(ds.std(ddof=1)),"kcnn_seed_wins":int((ds<0).sum()),"results":results}
    (OUT/'results.json').write_text(json.dumps(summary,indent=2,sort_keys=True));print(json.dumps({k:summary[k] for k in ['manifest_fingerprint','mean_difference','sd_difference','kcnn_seed_wins']},indent=2))
if __name__=='__main__':main()
