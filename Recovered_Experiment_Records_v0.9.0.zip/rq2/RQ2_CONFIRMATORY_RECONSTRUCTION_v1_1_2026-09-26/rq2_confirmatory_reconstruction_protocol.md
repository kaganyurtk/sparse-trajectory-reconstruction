# RQ2 confirmatory reconstruction protocol v1.1

Date frozen: 2026-09-26 (Europe/Istanbul)

## Amendment record

Revision 1.1 corrects the optimizer implementation to the frozen **Adam with coupled L2 weight
decay (0.0001)** specification. A completed revision-1.0 diagnostic run used decoupled AdamW and
is retained as a nonconformant audit artifact; it is excluded from scientific reporting. The split,
masks, architecture, seeds, physics weight, metrics and reporting rules were unchanged.

## Scientific status

This is a reconstruction and independent replication of the missing RQ2 final-evaluation artifacts. It is not described as the first opening of a sealed test because aggregate values from a previous, unavailable evaluation were already known. No group-level outcomes from the split defined here have been inspected before freezing this protocol.

## Data snapshot

- Source: public FlightSketch per-flight CSV files.
- Snapshot identity: the 614-flight manifest created on 2026-09-21.
- Integrity: 613 currently indexed flights match their historical SHA-256 values. Historical flight 4452 was fetched directly and matches its recorded SHA-256. Newly indexed flight 4814 is excluded.
- Technical exclusion: any flight whose recorded velocity falls below -500 ft/s is excluded before splitting and without inspecting model outcomes.
- Two nonidentifying provisional labels are excluded according to the 2026-09-23 identity register.
- Five formatting-only alias families are consolidated using the canonical operational-group identifiers in that register.

## Development and test boundary

- Any canonical operational group containing a source row marked `consistent_with_41_group_count_rule` in the identity register is development-only. This conservative rule keeps every possible member of the historical development cohort out of the test pool.
- The remaining groups form the candidate pool.
- Candidate groups are ordered by SHA-256 of `rq2-confirmatory-reconstruction-v1::<canonical_operational_group_id>`.
- The first eight groups form the test set. The technical velocity rule is then applied at flight level.
- Development groups are ordered by SHA-256 of `rq2-confirmatory-reconstruction-v1-inner::<canonical_operational_group_id>`. The first six form inner validation and the rest form fit data.
- No test result can change the split, preprocessing, model, loss, seed, stopping rule or reporting rule.

## Preprocessing

- Use finite time, altitude and velocity rows sorted by time.
- Linearly interpolate altitude and velocity to a 1 Hz grid spanning the available record.
- Convert feet and feet per second to metres and metres per second.
- Retain 5% of grid points with at least two points per flight. Endpoints are always observed; remaining observations are selected by a fixed SHA-256 order of flight ID and grid index.
- Model inputs are normalized time, linearly interpolated sparse altitude and velocity, normalized distance to the nearest observation, flight duration, an observation indicator and log observation ratio.
- Feature and target scaling are computed from fit flights only.

## Models

- NN: two 32-unit tanh hidden layers and two continuous standardized outputs.
- KC-NN: identical network, initialization and optimizer with an additional finite-difference kinematic residual `dh/dt - v`.
- Data loss: equal-weight mean squared error of standardized altitude and velocity.
- Kinematic loss: mean squared residual after division by the fit velocity standard deviation.
- Kinematic weight: 1.91, the frozen 5% value in the prior RQ2 method record.
- Optimizer: Adam, learning rate 0.001, coupled L2 weight decay 0.0001.
- Maximum epochs: 3000; early stopping uses inner-validation data loss with patience 250.
- Paired seeds: 11, 29, 47, 71 and 97.

## Outcomes

- Altitude RMSE in metres.
- Velocity RMSE in metres per second.
- Equal-weight combined score: one half of altitude RMSE divided by the fit altitude standard deviation plus one half of velocity RMSE divided by the fit velocity standard deviation.
- Primary contrast: KC-NN minus NN combined score at 5% observations, paired by seed. Negative values favor KC-NN.
- Report the mean and sample standard deviation of paired seed differences, seed wins, flight count, group count, component RMSEs and group-level paired effects.

## Interpretation limit

Groups are provisional uploader-plus-normalized-title operational units. They are not confirmed physical airframes or configurations. Seeds measure optimization variability and are not independent vehicles.
