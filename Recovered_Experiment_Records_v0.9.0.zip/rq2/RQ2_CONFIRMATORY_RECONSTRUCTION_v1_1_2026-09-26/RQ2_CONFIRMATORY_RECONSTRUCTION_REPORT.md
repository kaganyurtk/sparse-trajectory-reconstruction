# RQ2 confirmatory reconstruction v1.1

**Run date:** 26 September 2026  
**Status:** completed and independently replay-verified  
**Primary comparison:** KC-NN minus NN combined standardized score at 5% observations

## Result

The unconstrained NN generalized better on the newly versioned group-held-out cohort. Mean combined score was **0.6096 ± 0.0274** for NN and **0.7145 ± 0.0369** for KC-NN. The paired difference was **+0.1049 ± 0.0558**, corresponding to a 17.2% increase relative to the NN mean. KC-NN won **0 of 5** paired seeds.

| Method | Altitude RMSE, m | Velocity RMSE, m/s | Combined score |
|---|---:|---:|---:|
| NN | 44.73 ± 3.63 | 10.14 ± 0.23 | 0.6096 ± 0.0274 |
| KC-NN | 57.52 ± 3.46 | 11.04 ± 0.77 | 0.7145 ± 0.0369 |

Every paired difference was positive (range 0.0188 to 0.1689); lower scores are better. The kinematic equality therefore did not reproduce the small, unstable 5% benefit seen during development.

## Cohort and frozen method

- Exact 614-file historical source snapshot restored; all 614 SHA-256 hashes matched.
- Previously development-exposed or plausibly exposed operational groups were kept in fit/validation only.
- Fit: 363 flights in 31 provisional operational groups.
- Inner validation: 75 flights in 6 groups.
- Held-out evaluation: 46 flights in 8 groups.
- Fixed 5% masks, 1 Hz interpolation, fit-only scaling, two 32-unit tanh layers, Adam with coupled L2 weight decay, seeds 11/29/47/71/97, and physics weight 1.91.
- Manifest fingerprint: `9efc8c68fc63ac7603e471e101571417017ac5bfb51398fa2f718396761f8782`.

## Verification

All checks passed: manifest fingerprint, pairwise group separation, test counts, exact test IDs, fit scaling parameters, and metric replay from all 10 saved checkpoints. Each replay matched the recorded altitude RMSE, velocity RMSE, and combined score within 1e-12.

## Interpretation boundary

This is a **confirmatory reconstruction / independent replication**, not the original pristine sealed final test. The exact historical 41-group assignment was absent, and aggregate final-looking values had already appeared in prior text. A new versioned split was therefore defined from metadata and quality rules before outcomes were computed. Public titles still support only provisional uploader-plus-normalized-title groups, not confirmed physical airframes.

Revision 1.1 corrects the optimizer implementation to the frozen Adam with coupled L2 weight-decay specification. The revision-1.0 AdamW diagnostic is excluded from scientific reporting; the split, masks and all other frozen choices were unchanged.

The result supports the paper's mechanism-level conclusion: imposing an exact altitude-rate/recorded-velocity equality can reduce generalization when the two measured channels are not exactly consistent. It does not establish broad cross-operator or cross-vehicle performance.
