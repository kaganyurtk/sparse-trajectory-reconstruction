# When kinematic constraints conflict with rocket telemetry: sparse trajectory reconstruction across two real-flight datasets

**Target journal:** Acta Astronautica · **Article type:** Original research · **Status:** Revised scientific draft with verified RQ2 reconstruction v1.1; figures, references and author declarations remain to be completed.

**Authors and affiliations:** [Insert and confirm with all contributors]

## Abstract

Real rocket telemetry is scarce, heterogeneous and sparsely sampled. We tested whether kinematic constraints improve neural reconstruction of altitude and velocity in two real-flight studies. RQ1 used 40 Falcon 9 flights sampled at 1 Hz over the first 120 s, with 28 training, six outer-validation and six held-out test flights. RQ2 development used 335 public FlightSketch flights from 41 provisional uploader-plus-normalized-title groups. Both studies compared matched unconstrained and kinematically constrained neural networks under fixed sparse-observation masks. At 5% observations in the RQ1 test set, the constraint reduced altitude RMSE from 2304.55 to 1920.30 m and the kinematic-violation rate from 0.4262 to 0.0612, but increased speed RMSE from 46.77 to 69.87 m/s. Combined standardized error increased by 0.018634; the constrained model won on one of six flights. A targeted Iridium-family replication met the flight-level improvement criterion on only two of five flights, below the prespecified four-of-five threshold. In RQ2 development, a small benefit at 5% observations (score 0.3479 to 0.3449; three of five seeds) reversed in all 20 paired comparisons at 10–100%. Because the original final-test artifact and exact historical assignments were absent, we performed a versioned confirmatory reconstruction using all plausibly development-exposed groups only for fit/validation and 46 held-out flights from eight newly allocated provisional groups. At 5% observations, NN versus constrained NN altitude RMSE was 44.73 versus 57.52 m, velocity RMSE 10.14 versus 11.04 m/s, and combined score 0.6096 versus 0.7145 (paired difference 0.1049 ± 0.0558 SD; zero of five seed wins). The mean mismatch between the altitude derivative and recorded velocity was 5.55 m/s in the historical development cohort. Physical plausibility did not guarantee improved predictive generalization: constraints must respect measurement semantics and be tested across flights.

**Keywords:** rocket telemetry; sparse trajectory reconstruction; kinematic constraints; physics-informed machine learning; measurement consistency; held-out evaluation

## Highlights — separate submission file after final wording check

- Matched neural models were evaluated on two real rocket telemetry sources.
- A kinematic constraint reduced physical violations but worsened combined Falcon 9 test error.
- A targeted flight-family replication failed its prespecified consistency criterion.
- A versioned group-held-out FlightSketch replication found no constrained-model wins across five seeds.
- Measured channel mismatch offers a plausible, nonexclusive explanation for the failure.

## 1. Introduction

Sparse observations make flight trajectory reconstruction an underdetermined task. Neural networks can reconstruct smooth altitude and velocity histories, while physical penalties may discourage implausible outputs. Yet the variables in a recorded telemetry stream need not correspond exactly to the state variables in an idealized physical law. Imposing an equality on filtered, quantized or differently timed channels can shift a prediction away from the measurements it is meant to reconstruct.

We examine this issue in early Falcon 9 webcast telemetry and public FlightSketch records. These are complementary observational settings, not interchangeable vehicle populations. Falcon 9 webcast speed denotes total speed; with unknown flight-path angle it should not be equated with vertical altitude rate. FlightSketch altitude and recorded velocity appear closer to a vertical kinematic pair, but their processed 1 Hz channels disagree empirically. Our primary question is whether adding the respective kinematic penalty improves held-out predictive accuracy under sparse observations, beyond increasing equation compliance.

This study contributes (i) a matched NN versus kinematically constrained NN comparison with fixed observation masks and held-out evaluations; (ii) flight-level scrutiny and a targeted replication of an apparently favorable case; and (iii) a measurement-channel audit to interpret an unfavorable held-out result. The contribution concerns empirical limits of this particular regularization on these telemetry sources. It does not imply that richer dynamics models, other observation models or all physics-informed methods fail.

**Related work to integrate before submission.** Position this study against physics-informed neural networks and loss-balancing work [1,2], sparse aerospace trajectory reconstruction [3], and real-observation physics-informed orbit determination [4]. Confirm bibliographic metadata and the precise comparison with [3,4] against the full papers; do not infer novelty solely from titles or abstracts.

## 2. Data and experimental design

### 2.1 Falcon 9 webcast telemetry (RQ1)

Forty flights contribute altitude and speed at 1 Hz from launch through 120 s (121 samples per flight). The fixed split has 28 training, six outer-validation and six held-out test flights. Training includes an inner fit/validation division of 22/6 flights. The outer-validation flights were visible during development and are not an independent final test. The six test flights were evaluated once with frozen models and no subsequent tuning. The measured speed is a magnitude, not an independently established vertical velocity. Record the specific extraction source, flight roster, units, preprocessing and sample provenance in the final supplement.

### 2.2 FlightSketch telemetry (RQ2)

The public index audit identified 4,040 records, 617 deterministic candidates and 614 initial technical passes. All 614 historical source-file SHA-256 values were restored and verified for the reconstruction. The frozen historical development cohort contains 335 flights, 17,864 processed 1 Hz samples and 41 *provisional* uploader-plus-normalized-title groups: 33 groups/257 flights for training and eight groups/78 flights for outer validation. Historical documentation recorded no final test and did not retain the exact 41-group assignment. We therefore defined reconstruction v1.1 conservatively: every canonical operational group containing a source row consistent with the historical development rule was restricted to fit or inner validation. The resulting fit set contained 363 flights/31 groups, inner validation contained 75 flights/six groups, and the newly allocated held-out set contained 46 usable flights/eight groups. Uploader/title membership cannot establish distinct physical airframes or configurations, and contributor concentration limits extrapolation beyond the represented uploader regime.

### 2.3 Sparse observations and comparison

Historical development used masks retaining 5, 10, 25, 50 or 100% of each trajectory; reconstruction v1.1 evaluated the prespecified primary 5% condition. For each 1 Hz trajectory, endpoints were retained and the remaining observations were chosen by a fixed SHA-256 ordering until max(2, ceil(0.05n)) samples were observed. The two principal models shared paired initialization, inputs, optimizer, mask and evaluation data. Both used two 32-unit tanh hidden layers, two standardized outputs, fit-only scaling, Adam with learning rate 0.001 and coupled L2 weight decay 0.0001, at most 3000 epochs, and inner-validation early stopping with patience 250. Inputs were normalized time, linearly interpolated sparse altitude and velocity, normalized distance to the nearest observation, duration, an observation indicator and log observation ratio. Five paired seeds (11, 29, 47, 71 and 97) were fixed.

## 3. Kinematic formulations and evaluation

Let h(t) be predicted altitude and s(t) the Falcon 9 webcast speed magnitude. In RQ1, the constrained network penalizes violations of a physically admissible early-ascent inequality relating altitude rate to total speed, rather than imposing dh/dt = s. **Insert the exact frozen loss and all term weights from the RQ1 protocol here.** A compact illustrative form is max(0, dh/dt − s), but this is not asserted to be the entire implemented loss. The reported violation rate must be defined by the frozen threshold and denominator.

For RQ2, let h_i and v_i denote predicted altitude and recorded-channel velocity at adjacent 1 Hz grid points. Reconstruction v1.1 used the normalized finite-difference residual r_i = [(h_{i+1} − h_i)/Δt_i − (v_i + v_{i+1})/2]/σ_v, where σ_v is the fit-set velocity target standard deviation. The NN minimized the mean squared error over the two standardized outputs. KC-NN added 1.91 times the mean squared residual, using the frozen 5% physics weight from development.

Altitude and velocity errors are reported as RMSE in physical units. The combined standardized score is 0.5(RMSE_h/σ_h + RMSE_v/σ_v), using fit-set target standard deviations σ_h and σ_v. Compute KC-NN minus NN within each paired seed, so a positive difference means the constraint worsens the score. Report flight/group-level effects alongside averages. Seed variability measures training sensitivity, not independent flight-level uncertainty. For RQ1, report the existing flight bootstrap interval separately, with its resampling unit and computation rule. All claims of cross-group generalization refer to provisional metadata groups.

## 4. Results

### 4.1 Falcon 9 held-out evaluation

At 5% observations, NN versus KC-NN altitude RMSE was 2304.55 versus 1920.30 m, while speed RMSE was 46.77 versus 69.87 m/s. The kinematic-violation rate fell from 0.4262 to 0.0612. Yet the prespecified combined score difference (KC-NN minus NN) was +0.018634, with a constrained-model advantage on one of six held-out flights. The RQ1 closure audit reports a flight bootstrap 95% interval of −0.020757 to +0.045011. This interval includes zero; avoid presenting six flights as conclusive evidence of a population-wide effect.

The favorable test flight, Iridium NEXT-5, motivated a *targeted post-hoc* mechanism and family study. In the locked five-flight leave-one-flight-out replication, the upper-bound-only variant beat the NN on two of five flights (NEXT-4 and NEXT-8), below the prespecified ≥4/5 criterion. This study is subsequent to, and must be clearly distinguished from, the original confirmatory RQ1 test. The apparent mean gain was concentrated in two flights, with heterogeneous effects elsewhere.

### 4.2 FlightSketch development and held-out evaluation

Development at 5% observations gave a combined score of 0.3479 for NN and 0.3449 for KC-NN; the constrained model won three of five paired seeds. At 10, 25, 50 and 100% observations it lost all 20 paired seed comparisons. This development signal did not establish a robust benefit.

Confirmatory reconstruction v1.1 evaluated eight newly allocated provisional groups and 46 usable flights at 5% observations. Across five paired seeds, NN versus KC-NN altitude RMSE was 44.73 ± 3.63 versus 57.52 ± 3.46 m and velocity RMSE was 10.14 ± 0.23 versus 11.04 ± 0.77 m/s. The combined score rose from 0.6096 ± 0.0274 to 0.7145 ± 0.0369. The paired increase was 0.1049 ± 0.0558 (sample SD), with zero of five seed wins for KC-NN. All ten saved checkpoints reproduced the recorded metrics within 10⁻¹², the eight evaluation groups were disjoint from fit/validation groups, and the manifest fingerprint was `9efc8c68fc63ac7603e471e101571417017ac5bfb51398fa2f718396761f8782`. Seeds quantify optimization variability and are not independent test cohorts.

### 4.3 Channel mismatch

The development cohort's 1 Hz numerical altitude derivative and recorded velocity disagree by an average **residual RMSE** of 5.55 m/s across 335 flights (median flight residual RMSE 4.50 m/s), according to the earlier development draft. This is a candidate explanation for the equality penalty's unfavorable behavior; filtering, interpolation, time alignment and channel definition remain unresolved alternatives. The number is not a mean signed error, nor proof of any specific sensor mechanism.

## 5. Discussion

Constraint compliance and predictive accuracy answer different questions. RQ1 demonstrates the tradeoff directly: fewer inequality violations and better altitude reconstruction occurred alongside worse speed reconstruction and a worse combined score. A single favorable held-out flight did not pass the targeted family consistency criterion. RQ2 shows a fragile sparse-data development improvement reversing in a newly versioned group-held-out replication. The equality residual also conflicts with the processed channel pair. These findings favor explicit measurement models and flight-level evaluation when adding a physical penalty to telemetry reconstruction.

The result is deliberately narrow. Falcon 9 is one vehicle family and only its first 120 s were studied. FlightSketch's operational groups are not verified physical vehicles, and its records are dominated by one contributor. The penalty is kinematic rather than a complete thrust, drag, mass-loss and flight-path dynamics model. The channel mismatch identifies a plausible mechanism, not a controlled causal isolation. Neither dataset supports a blanket conclusion about all PINNs, all rockets or unseen confirmed airframes.

## 6. Conclusion

On these two real-flight telemetry studies, the investigated kinematic penalties did not produce a reliable improvement in the prespecified held-out reconstruction scores. Greater physical compliance alone was insufficient. A useful constraint must correspond to the recorded channels and survive evaluation across independent flights or defensibly defined groups.

## Submission material and author-controlled declarations

**Figures/tables to assemble:** (1) RQ1 held-out score and two component RMSEs, including violation rate; (2) six individual test-flight effects and bootstrap interval; (3) explicitly labeled post-hoc Iridium-family replication; (4) RQ2 development mask curve; (5) RQ2 reconstruction-v1.1 paired seed effects; (6) altitude-derivative versus recorded-velocity mismatch. Use existing verified figure assets where available, with captions that distinguish development, held-out and post-hoc analyses.

**Data and code availability:** [Authors to insert final release locations, licenses/permissions, raw versus processed sharing scope, frozen code revision, run manifest and access conditions. A prior draft states FlightSketch redistribution permission is complete; verify the exact written authorization and attribution requirements before release.]

**Funding:** [Authors to declare.] **Competing interests:** [Each author to confirm.] **CRediT contributions:** [Authors to approve roles.] **Ethics/permissions:** [State only what the source permissions support.]

**Declaration of generative AI in scientific writing:** During manuscript preparation, OpenAI ChatGPT was used to help reorganize and draft prose for the target journal. Human authors must verify every scientific statement, result, citation and formulation, revise the text, and accept responsibility for the submitted article. [Authors to confirm other AI uses, tools and precise scope before submission.]

## References — verify against original papers and complete

1. Raissi M, Perdikaris P, Karniadakis GE. Physics-informed neural networks: A deep learning framework for solving forward and inverse problems involving nonlinear partial differential equations. *J Comput Phys* 378 (2019) 686–707. https://doi.org/10.1016/j.jcp.2018.10.045
2. Wang S, Teng Y, Perdikaris P. Understanding and mitigating gradient flow pathologies in physics-informed neural networks. *SIAM J Sci Comput* 43(5) (2021) A3055–A3081. https://doi.org/10.1137/20M1318043
3. Trajectory reconstruction for nanosatellite in very low Earth orbit using machine learning. *Acta Astronautica* (2022). [Verify complete authors, volume, pages, DOI and relevance.]
4. Physics-informed orbit determination for X-GEO space situational awareness. *Acta Astronautica* (2026). [Verify complete authors, volume, pages, DOI and relevance.]

## Editorial verification note (remove before submission)

This draft incorporates the verified RQ1 closure audit, historical RQ2 development evidence, and RQ2 confirmatory reconstruction v1.1. The earlier author-supplied RQ2 aggregate values (0.3067 versus 0.3333) were not supported by files in Drive and have been replaced by replay-verified v1.1 values. Because prior aggregate values had been exposed and the exact historical 41-group assignment was missing, v1.1 is described as a confirmatory reconstruction / independent replication rather than the original pristine sealed final test. The revision-1.0 AdamW diagnostic is excluded; revision 1.1 conforms to the frozen Adam with coupled L2 weight-decay specification. Confirm journal-specific limits, references and submission fields before submission.
