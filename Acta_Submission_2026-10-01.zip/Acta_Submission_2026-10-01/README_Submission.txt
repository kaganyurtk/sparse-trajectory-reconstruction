Submission working copy dated 2026-10-01. No journal submission has been made.
The frozen Zenodo v0.9.0 archive is unchanged. The updated manuscript and supplement correct availability and describe the actual archived RQ2 implementation.
Read Acta_Submission_Checklist_TR.docx before submission. Numerical results and embedded figure bytes are unchanged.

GitHub writeback was not completed: the connected integration returned HTTP 403, Resource not accessible by integration. No repository files or tags were changed in this submission-preparation step.
The github_updates directory contains prepared README.md, CITATION.cff and ZENODO_METADATA.md replacements, not applied updates.
When authorized write access is restored, use the manuscript and supplement as replacements for the corresponding root Acta_Astronautica_*.docx files and place the auxiliary documents under submission/2026-10-01/. Preserve the published v0.9.0 tag and Zenodo archive.
This package was not uploaded to Google Drive during this step.
