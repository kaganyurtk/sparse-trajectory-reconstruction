Submission working copy prepared October 1 and revised October 2, 2026. No journal submission has been made.
The public Zenodo v0.9.0 archive remains frozen. These manuscript and supplement files describe the actual archived RQ2 implementation and the public FlightSketch source; they do not assert that a separate research permission was obtained.
Read Acta_Submission_Checklist_TR.docx before journal submission. Numerical results and figure bytes are unchanged. The raw third-party FlightSketch CSV files are not included.
The current submission documents are maintained on the main branch of https://github.com/kaganyurtk/sparse-trajectory-reconstruction. The older Acta_Astronautica_*.docx files are the frozen v0.9 snapshots, not the submission working copies.
